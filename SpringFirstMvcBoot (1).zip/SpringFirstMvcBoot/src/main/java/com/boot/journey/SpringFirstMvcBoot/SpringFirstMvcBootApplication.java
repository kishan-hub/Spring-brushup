package com.boot.journey.SpringFirstMvcBoot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringFirstMvcBootApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringFirstMvcBootApplication.class, args);
	}

}
